## CSCI-1175-Industry-Project:

## Chapter 28:
 Exercise 28-3: Implement DFS using a stack
This exercise likely involves implementing Depth-First Search algorithm using a stack data structure.
 Exercise 28-5: Find paths between two vertices
You'll probably need to write code to find paths between two vertices in a graph.
 Exercise 28-7: Find a cycle in a graph
This exercise may involve writing code to detect cycles in a graph, which is a common problem in graph theory.
## Chapter 31:
 Exercise 31-17: Create an Investment value calculator
You'll need to create a calculator that calculates the value of an investment based on certain parameters.
 Exercise 31-20: Use tab Pane and add a Pane of Radio Buttons
This exercise involves creating a user interface with tab panes and radio buttons, likely using a GUI library like JavaFX.
 Exercise 31-22: Use table view and add a button to delete the selected row
You'll have to create a UI with a table view and a button that allows users to delete selected rows from the table.
## Chapter 32:
 Exercise 32-3: Raise Flags to animate using a thread
This exercise may involve animating flags using threads, possibly in a graphical application.
 Exercise 32-13: Generic parallel Merge sort
You'll need to implement a parallel version of the merge sort algorithm.
## Chapter 33:
 Exercise 33-1: Loan server Client-side to server-side data transfer
You'll likely implement a client-server application for transferring loan-related data.
 Exercise 33-9: Chat Client-side to server-side message box and message history. Write a README for GitHub
This exercise involves creating a chat application with message history, implemented both client-side and server-side. Additionally, you'll need to write a README file for GitHub to explain your project.
