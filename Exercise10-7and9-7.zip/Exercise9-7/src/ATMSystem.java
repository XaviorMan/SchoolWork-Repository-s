import java.util.Scanner;

public class ATMSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create ten accounts with initial balance $100
        Account[] accounts = new Account[10];
        for (int i = 0; i < 10; i++) {
            accounts[i] = new Account(i, 100.0);
        }

        while (true) {
            // Prompt the user to enter an id
            System.out.print("Enter an id: ");
            int id = scanner.nextInt();

            // Validate the id
            if (id < 0 || id >= 10) {
                System.out.println("Incorrect id. Please enter a correct id.");
                continue; // Go back to the beginning of the loop
            }

            // Display the main menu
            int choice;
            do {
                System.out.println("\nMain menu:");
                System.out.println("1: View current balance");
                System.out.println("2: Withdraw money");
                System.out.println("3: Deposit money");
                System.out.println("4: Exit");
                System.out.print("Enter a choice: ");
                choice = scanner.nextInt();

                // Perform actions based on user choice
                switch (choice) {
                    case 1:
                        // View current balance
                        System.out.println("Current balance: $" + accounts[id].getBalance());
                        break;
                    case 2:
                        // Withdraw money
                        System.out.print("Enter the amount to withdraw: $");
                        double withdrawAmount = scanner.nextDouble();
                        accounts[id].withdraw(withdrawAmount);
                        break;
                    case 3:
                        // Deposit money
                        System.out.print("Enter the amount to deposit: $");
                        double depositAmount = scanner.nextDouble();
                        accounts[id].deposit(depositAmount);
                        break;
                    case 4:
                        // Exit the main menu
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a valid choice.");
                }
            } while (choice != 4);
            
        }
     
    }
}
