import java.util.Date;

public class Account {
    private int id;
    private double balance;
    private double annualInterestRate;
    private Date dateCreated;

    // Default constructor
    public Account() {
        id = 0;
        balance = 0;
        annualInterestRate = 0;
        dateCreated = new Date();
    }

    // Constructor with specified id and initial balance
    public Account(int newId, double newBalance) {
        id = newId;
        balance = newBalance;
        annualInterestRate = 0;
        dateCreated = new Date();
    }

    // Accessor and mutator methods for id
    public int getId() {
        return id;
    }

    public void setId(int newId) {
        id = newId;
    }

    // Accessor and mutator methods for balance
    public double getBalance() {
        return balance;
    }

    public void setBalance(double newBalance) {
        balance = newBalance;
    }

    // Accessor and mutator methods for annualInterestRate
    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double newAnnualInterestRate) {
        annualInterestRate = newAnnualInterestRate;
    }

    // Accessor method for dateCreated
    public Date getDateCreated() {
        return dateCreated;
    }

    // Method to get monthly interest rate
    public double getMonthlyInterestRate() {
        return annualInterestRate / 12 / 100;
    }

    // Method to calculate and return monthly interest
    public double getMonthlyInterest() {
        return balance * getMonthlyInterestRate();
    }

    // Method to withdraw a specified amount
    public void withdraw(double amount) {
   
    		balance -= amount;
    	}

    // Method to deposit a specified amount
    public void deposit(double amount) {
        balance += amount;
    }

    // Test program
    public static void main(String[] args) {
        // Create an Account object
        Account account = new Account(1122, 20000);
        
        // Set annual interest rate
        account.setAnnualInterestRate(4.5);

        // Withdraw $2,500
        account.withdraw(2500);

        // Deposit $3,000
        account.deposit(3000);

        // Print balance, monthly interest, and date created
        System.out.println("Balance: $" + account.getBalance());
        System.out.println("Monthly Interest: $" + account.getMonthlyInterest());
        System.out.println("Date Created: " + account.getDateCreated());
    }
}
