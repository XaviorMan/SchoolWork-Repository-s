
public class TestOctagon {
    public static void main(String[] args) {
        Octagon octagon1 = new Octagon(5.0);

        Octagon octagon2 = octagon1.clone();

        int comparisonResult = octagon1.compareTo(octagon2);

        System.out.println("Area of Octagon 1: " + octagon1.getArea());
        System.out.println("Area of Octagon 2: " + octagon2.getArea());
        System.out.println("Comparison result: " + comparisonResult);
    }
}