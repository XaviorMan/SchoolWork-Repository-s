import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class FileReadWriteExample {

    public static void main(String[] args) {
        FileReadWriteExample example = new FileReadWriteExample();
        int[] data = example.generateRandomIntegers(100);
        String fileName = "data.txt";

        example.writeToFile(data, fileName);

        int[] readData = example.readFromFile(fileName);

        System.out.println("Original Data: " + Arrays.toString(data));
        System.out.println("Data Read from File: " + Arrays.toString(readData));
    }

    // Method to write an array of integers to a file
    public void writeToFile(int[] data, String fileName) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (int value : data) {
                writer.println(value);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to read an array of integers from a file
    public int[] readFromFile(String fileName) {
        List<Integer> resultList = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int value = Integer.parseInt(line.trim());
                resultList.add(value);
            }
        } catch (IOException | NumberFormatException e) {
            e.printStackTrace();
        }

        return resultList.stream().mapToInt(Integer::intValue).toArray();
    }


    // Method to generate an array of random integers
    public int[] generateRandomIntegers(int count) {
        int[] result = new int[count];
        Random random = new Random();
        for (int i = 0; i < count; i++) {
            result[i] = random.nextInt(100);
        }
        return result;
    }

    // Method to convert a string array to an int array
    public int[] convertStringArrayToIntArray(String[] strings) {
        int[] result = new int[strings.length];
        for (int i = 0; i < strings.length; i++) {
            result[i] = Integer.parseInt(strings[i]);
        }
        return result;
    }

    // Method to sort an int array
    public void sortIntArray(int[] array) {
        Arrays.sort(array);
    }
}

