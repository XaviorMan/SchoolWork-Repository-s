## Object-Oriented-Programming at Southwest Technical Collage
Joshua X Mechem

This repository exists to hold assignments for the class Object-Oriented Programming. At this time, the only folder it holds is the README.md file.  

I believe that mastering object-oriented programming principles will enhance my ability to design efficient and maintainable code. This class presents an opportunity to delve deeper into concepts such as encapsulation, inheritance, and polymorphism, paving the way for me to become a more proficient and versatile programmer.
