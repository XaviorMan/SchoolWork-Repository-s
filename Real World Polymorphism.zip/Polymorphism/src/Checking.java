
public class Checking extends Account {
    private double overdraftLimit;

    public Checking(int accountNumber, double balance, double annualInterest, double overdraftLimit) {
        super(accountNumber, balance, annualInterest);
        this.overdraftLimit = overdraftLimit;
    }

    public double getOverdraftLimit() {
        return overdraftLimit;
    }
}
