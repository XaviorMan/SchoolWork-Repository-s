
public class Saving extends Account {
    public Saving(int accountNumber, double balance, double annualInterest) {
        super(accountNumber, balance, annualInterest);
    }

    public void connOverdraft() {
    }
}
