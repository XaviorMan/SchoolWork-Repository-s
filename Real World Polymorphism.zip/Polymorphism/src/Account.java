import java.util.Date;

public class Account {
    protected int accountNumber;
    protected double balance;
    protected double annualInterest;
    protected Date dateCreated;
    
    public double getBalance() {
    	return balance;
    }

    public Account(int accountNumber, double balance, double annualInterest) {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.annualInterest = annualInterest;
        this.dateCreated = new Date();
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        balance -= amount;
    }

    public void transferTo(double amount, Account targetAccount) {
        withdraw(amount);
        targetAccount.deposit(amount);
    }
}
