import org.junit.Test;
import static org.junit.Assert.*;

public class AccountTest {

    @Test
    public void testAccountDeposit() {
        Account account = new Account(1, 100.0, 0.02);
        account.deposit(50.0);
        assertEquals(150.0, account.getBalance(), 0.01);
    }

    @Test
    public void testAccountWithdraw() {
        Account account = new Account(2, 200.0, 0.03);
        account.withdraw(30.0);
        assertEquals(170.0, account.getBalance(), 0.01);
    }

    @Test
    public void testAccountTransferTo() {
        Account sourceAccount = new Account(3, 300.0, 0.04);
        Account targetAccount = new Account(4, 400.0, 0.05);

        sourceAccount.transferTo(50.0, targetAccount);

        assertEquals(250.0, sourceAccount.getBalance(), 0.01);
        assertEquals(450.0, targetAccount.getBalance(), 0.01);
    }

    @Test
    public void testCheckingOverdraftLimit() {
        Checking checkingAccount = new Checking(5, 100.0, 0.02, 50.0);

        // Test the overdraft limit
        assertEquals(50.0, checkingAccount.getOverdraftLimit(), 0.01);

        // Perform a withdrawal within the overdraft limit
        checkingAccount.withdraw(30.0);
        assertEquals(70.0, checkingAccount.getBalance(), 0.01);

        // Perform a withdrawal exceeding the overdraft limit
        checkingAccount.withdraw(80.0);
        assertEquals(-10.0, checkingAccount.getBalance(), 0.01);
    }

    @Test
    public void testSavingConnOverdraft() {
        Saving savingAccount = new Saving(6, 200.0, 0.03);
        savingAccount.connOverdraft();
        // Add assertions specific to the connOverdraft method if needed
    }
}
