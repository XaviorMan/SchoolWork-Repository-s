# CSCI_1112_OOP2_Coursework

##  This repository is meant to help me keep my assignments in one place for my Object-Oriented Programming class.

## If you would like to start the Object-Oriented Programming class, reach out to your local college or university and see if they offer it as a course. If they do not have it available, look online for a place that offers it.

## I should be the only one to contribute to this because it is my homework.
