# FirstJavaPrograms
This is a repository of different small project I have worked on.
