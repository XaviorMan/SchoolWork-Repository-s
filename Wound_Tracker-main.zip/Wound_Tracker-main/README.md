# Wound_Tracker

## Synopsis
This project is a way for players of Age of Sigmar to track their unit's different wounds.

## Motivation
I just started playing Age of Sigmar and keeping track of unit wounds would get in the way of me trying to think of what to do in the game.

## Test
The tests are built into the program one of the tests will check if the unit and its wounds are being written out to a file properly, and the other test will check if there is stuff written out to the file.
